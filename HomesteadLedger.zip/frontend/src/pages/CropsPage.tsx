import { useEffect, useState } from "react";
import axios from "axios";
import { Typography, Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Button, Box } from "@mui/material";

type Crop = {
  id: number;
  crop_type: string;
  variety?: string;
  plant_date?: string;
  bed_id?: number;
  estimated_first_harvest?: string;
  estimated_last_harvest?: string;
  estimated_yield?: number;
  yield_unit?: string;
  status?: string;
  notes?: string;
};

export default function CropsPage() {
  const [crops, setCrops] = useState<Crop[]>([]);

  useEffect(() => {
    axios.get("/api/crops/")
      .then(res => setCrops(res.data));
  }, []);

  return (
    <Box>
      <Typography variant="h4" gutterBottom>Crops</Typography>
      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Crop Type</TableCell>
              <TableCell>Variety</TableCell>
              <TableCell>Plant Date</TableCell>
              <TableCell>Status</TableCell>
              <TableCell>Notes</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {crops.map((crop) => (
              <TableRow key={crop.id}>
                <TableCell>{crop.crop_type}</TableCell>
                <TableCell>{crop.variety}</TableCell>
                <TableCell>{crop.plant_date}</TableCell>
                <TableCell>{crop.status}</TableCell>
                <TableCell>{crop.notes}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
      <Button variant="contained" sx={{ mt: 2 }}>Add Crop</Button>
    </Box>
  );
}