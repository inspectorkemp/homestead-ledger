import { useEffect, useState } from "react";
import axios from "axios";
import { Typography, Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Button, Box } from "@mui/material";

type Chicken = {
  id: number;
  name: string;
  breed?: string;
  purpose: string;
  sex: string;
  hatch_date?: string;
  acquired_date?: string;
  status?: string;
  notes?: string;
};

export default function ChickensPage() {
  const [chickens, setChickens] = useState<Chicken[]>([]);

  useEffect(() => {
    axios.get("/api/chickens/")
      .then(res => setChickens(res.data));
  }, []);

  return (
    <Box>
      <Typography variant="h4" gutterBottom>Chickens</Typography>
      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Name</TableCell>
              <TableCell>Breed</TableCell>
              <TableCell>Purpose</TableCell>
              <TableCell>Sex</TableCell>
              <TableCell>Status</TableCell>
              <TableCell>Notes</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {chickens.map((chicken) => (
              <TableRow key={chicken.id}>
                <TableCell>{chicken.name}</TableCell>
                <TableCell>{chicken.breed}</TableCell>
                <TableCell>{chicken.purpose}</TableCell>
                <TableCell>{chicken.sex}</TableCell>
                <TableCell>{chicken.status}</TableCell>
                <TableCell>{chicken.notes}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
      <Button variant="contained" sx={{ mt: 2 }}>Add Chicken</Button>
    </Box>
  );
}