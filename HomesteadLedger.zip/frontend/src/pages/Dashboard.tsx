import { Typography, Grid, Paper } from "@mui/material";
import { Link } from "react-router-dom";

export default function Dashboard() {
  return (
    <div>
      <Typography variant="h3" gutterBottom>Homestead Dashboard</Typography>
      <Grid container spacing={3}>
        <Grid item xs={12} md={6} lg={4}>
          <Paper sx={{ p: 2 }}>
            <Typography variant="h6" component={Link} to="/garden-beds">Garden Beds</Typography>
            <Typography>Manage your garden beds and their crops.</Typography>
          </Paper>
        </Grid>
        <Grid item xs={12} md={6} lg={4}>
          <Paper sx={{ p: 2 }}>
            <Typography variant="h6" component={Link} to="/crops">Crops</Typography>
            <Typography>Track crops, harvests, and treatments.</Typography>
          </Paper>
        </Grid>
        <Grid item xs={12} md={6} lg={4}>
          <Paper sx={{ p: 2 }}>
            <Typography variant="h6" component={Link} to="/chickens">Chickens</Typography>
            <Typography>Monitor your flock, eggs, and more.</Typography>
          </Paper>
        </Grid>
        <Grid item xs={12} md={6} lg={4}>
          <Paper sx={{ p: 2 }}>
            <Typography variant="h6" component={Link} to="/pets">Pets</Typography>
            <Typography>Keep records for dogs, cats, and other pets.</Typography>
          </Paper>
        </Grid>
        <Grid item xs={12} md={6} lg={4}>
          <Paper sx={{ p: 2 }}>
            <Typography variant="h6" component={Link} to="/equipment">Equipment</Typography>
            <Typography>Track equipment and maintenance.</Typography>
          </Paper>
        </Grid>
      </Grid>
    </div>
  );
}