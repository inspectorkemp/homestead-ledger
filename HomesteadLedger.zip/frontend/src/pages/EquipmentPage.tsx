import { useEffect, useState } from "react";
import axios from "axios";
import { Typography, Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Button, Box } from "@mui/material";

type Equipment = {
  id: number;
  name: string;
  brand?: string;
  model?: string;
  purchase_date?: string;
  status?: string;
  notes?: string;
};

export default function EquipmentPage() {
  const [equipment, setEquipment] = useState<Equipment[]>([]);

  useEffect(() => {
    axios.get("/api/equipment/")
      .then(res => setEquipment(res.data));
  }, []);

  return (
    <Box>
      <Typography variant="h4" gutterBottom>Equipment</Typography>
      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Name</TableCell>
              <TableCell>Brand</TableCell>
              <TableCell>Model</TableCell>
              <TableCell>Status</TableCell>
              <TableCell>Notes</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {equipment.map((equip) => (
              <TableRow key={equip.id}>
                <TableCell>{equip.name}</TableCell>
                <TableCell>{equip.brand}</TableCell>
                <TableCell>{equip.model}</TableCell>
                <TableCell>{equip.status}</TableCell>
                <TableCell>{equip.notes}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
      <Button variant="contained" sx={{ mt: 2 }}>Add Equipment</Button>
    </Box>
  );
}