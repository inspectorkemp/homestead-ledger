import { useEffect, useState } from "react";
import axios from "axios";
import { Typography, Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Button, Box } from "@mui/material";

type GardenBed = {
  id: number;
  name: string;
  soil_type?: string;
  area_sqft?: number;
  notes?: string;
};

export default function GardenBedsPage() {
  const [beds, setBeds] = useState<GardenBed[]>([]);

  useEffect(() => {
    axios.get("/api/garden_beds/")
      .then(res => setBeds(res.data));
  }, []);

  return (
    <Box>
      <Typography variant="h4" gutterBottom>Garden Beds</Typography>
      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Name</TableCell>
              <TableCell>Soil Type</TableCell>
              <TableCell>Area (sqft)</TableCell>
              <TableCell>Notes</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {beds.map((bed) => (
              <TableRow key={bed.id}>
                <TableCell>{bed.name}</TableCell>
                <TableCell>{bed.soil_type}</TableCell>
                <TableCell>{bed.area_sqft}</TableCell>
                <TableCell>{bed.notes}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
      <Button variant="contained" sx={{ mt: 2 }}>Add Garden Bed</Button>
    </Box>
  );
}