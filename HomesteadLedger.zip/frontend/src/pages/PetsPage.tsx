import { useEffect, useState } from "react";
import axios from "axios";
import { Typography, Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Button, Box } from "@mui/material";

type Pet = {
  id: number;
  name: string;
  species: string;
  breed?: string;
  sex: string;
  birth_date?: string;
  acquired_date?: string;
  status?: string;
  notes?: string;
};

export default function PetsPage() {
  const [pets, setPets] = useState<Pet[]>([]);

  useEffect(() => {
    axios.get("/api/pets/")
      .then(res => setPets(res.data));
  }, []);

  return (
    <Box>
      <Typography variant="h4" gutterBottom>Pets</Typography>
      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Name</TableCell>
              <TableCell>Species</TableCell>
              <TableCell>Breed</TableCell>
              <TableCell>Sex</TableCell>
              <TableCell>Status</TableCell>
              <TableCell>Notes</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {pets.map((pet) => (
              <TableRow key={pet.id}>
                <TableCell>{pet.name}</TableCell>
                <TableCell>{pet.species}</TableCell>
                <TableCell>{pet.breed}</TableCell>
                <TableCell>{pet.sex}</TableCell>
                <TableCell>{pet.status}</TableCell>
                <TableCell>{pet.notes}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
      <Button variant="contained" sx={{ mt: 2 }}>Add Pet</Button>
    </Box>
  );
}