import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
import { Container, AppBar, Toolbar, Typography, Button } from "@mui/material";
import GardenBedsPage from "./pages/GardenBedsPage";
import CropsPage from "./pages/CropsPage";
import ChickensPage from "./pages/ChickensPage";
import PetsPage from "./pages/PetsPage";
import EquipmentPage from "./pages/EquipmentPage";
import Dashboard from "./pages/Dashboard";

export default function App() {
  return (
    <BrowserRouter>
      <AppBar position="static">
        <Toolbar>
          <Typography variant="h6" sx={{ flexGrow: 1 }}>Homestead Portal</Typography>
          <Button color="inherit" component={Link} to="/">Dashboard</Button>
          <Button color="inherit" component={Link} to="/garden-beds">Garden Beds</Button>
          <Button color="inherit" component={Link} to="/crops">Crops</Button>
          <Button color="inherit" component={Link} to="/chickens">Chickens</Button>
          <Button color="inherit" component={Link} to="/pets">Pets</Button>
          <Button color="inherit" component={Link} to="/equipment">Equipment</Button>
        </Toolbar>
      </AppBar>
      <Container sx={{ mt: 4 }}>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/garden-beds" element={<GardenBedsPage />} />
          <Route path="/crops" element={<CropsPage />} />
          <Route path="/chickens" element={<ChickensPage />} />
          <Route path="/pets" element={<PetsPage />} />
          <Route path="/equipment" element={<EquipmentPage />} />
        </Routes>
      </Container>
    </BrowserRouter>
  );
}